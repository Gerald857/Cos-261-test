public class MultiplicationTable {
    public static void main(String[] args) {
        int n = 4;
        for (int i = 1; i <= 10; i++) {
            System.out.println(n + " x " + i + " = " + (n * i));
        }
    }
}