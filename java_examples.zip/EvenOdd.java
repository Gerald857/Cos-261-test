public class EvenOdd {
    public static void main(String[] args) {
        int num = 6;
        if (num % 2 == 0) {
            System.out.println("Even");
        } else {
            System.out.println("Odd");
        }
    }
}