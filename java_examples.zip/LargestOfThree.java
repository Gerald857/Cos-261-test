public class LargestOfThree {
    public static void main(String[] args) {
        int a = 5, b = 8, c = 3;
        int max = Math.max(a, Math.max(b, c));
        System.out.println("Max = " + max);
    }
}